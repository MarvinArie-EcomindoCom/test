from os import environ
from abc import ABC,abstractmethod 
from pyspark.sql import SparkSession
from pyspark.context import SparkContext
from pyspark.sql.functions import split, explode 
from ecomindo.spark.libraries.functions import start_spark

class SparkTask:

	def __init__(self):
		self.taskName = self.__class__.__name__
		self.spark = None
		self.log = None
		self.config = None

	def _startSpark(self, master='local[*]', jar_packages=[],
                files=[], spark_config={}, log_level=""):
		self.close()
		spark, log, config = start_spark(self.taskName, master, jar_packages, files, spark_config, log_level)
		self.spark = spark
		self.log = log
		self.config = config

	def close(self):
		if(self.spark is not None):
			if(self.log is not None): 
				self.log.info(f'{self.taskName} stop spark')
			self.spark.stop()

	@abstractmethod
	def run(self):
		pass